import dotenv from 'dotenv';
dotenv.config();
import './config/db.js'
import { 
  sequelize,
  User, 
  Profile, 
  Course, 
  Lesson, 
  Quiz, 
  Question, 
  QuizAttempt, 
  Achievement, 
  UserAchievement, 
  Activity, 
  Notification, 
  Enrollment 
} from './models/index.js';

const seedDatabase = async () => {
  try {
    console.log('🔄 Подключение к базе данных...');
    await sequelize.authenticate();
    console.log('✅ Подключение установлено успешно');

    // Синхронизация моделей (опционально - пересоздание таблиц)
    console.log('🔄 Синхронизация моделей...');
    await sequelize.sync({ force: true });
    console.log('✅ Модели синхронизированы');

    console.log('🗑️ Очистка базы данных...');
    // Последовательность удаления данных (важно для внешних ключей)
    await UserAchievement.destroy({ where: {} });
    await Achievement.destroy({ where: {} });
    await QuizAttempt.destroy({ where: {} });
    await Question.destroy({ where: {} });
    await Quiz.destroy({ where: {} });
    await Activity.destroy({ where: {} });
    await Notification.destroy({ where: {} });
    await Enrollment.destroy({ where: {} });
    await Lesson.destroy({ where: {} });
    await Course.destroy({ where: {} });
    await Profile.destroy({ where: {} });
    await User.destroy({ where: {} });
    console.log('✅ База данных очищена');

    console.log('📚 Создание курсов...');
    const courses = await Course.bulkCreate([
      {
        title: 'Математический Анализ',
        description: 'Фундаментальный курс по математическому анализу, охватывающий основные понятия и методы дифференциального и интегрального исчисления. Идеально подходит для студентов технических специальностей.',
        shortDescription: 'Основы математического анализа для начинающих',
        difficulty: 'Начинающий',
        duration: 4,
        price: 0.00,
        isPublished: true,
        publishedAt: new Date(),
        instructorId: null,
        rating: 4.8,
      },
    ]);
    console.log(`✅ Создано ${courses.length} курсов`);

    console.log('📖 Создание уроков...');
    const lessons = await Lesson.bulkCreate([
      {
        courseId: courses[0].id,
        title: 'Множества чисел',
        description: 'Изучение основных числовых множеств: натуральные, целые, рациональные, иррациональные и действительные числа. Свойства и операции над множествами.',
        content: 'В этом уроке мы рассмотрим основные числовые множества...',
        duration: 60,
        order: 1,
        isFree: true,
        videoUrl: 'https://res.cloudinary.com/dccnewrlr/video/upload/v1764252935/VID_20251127_170149_953_i12ngz.mp4',
        resources: [
          { id: '1', name: 'Конспект урока', type: 'pdf', size: '2.1 MB' },
          { id: '2', name: 'Практические задания', type: 'doc', size: '1.5 MB' }
        ]
      },
      {
        courseId: courses[0].id,
        title: 'Функции одной переменной',
        description: 'Понятие функции, способы задания функций, основные свойства функций. Область определения и множество значений.',
        content: 'Функция - это одно из фундаментальных понятий математического анализа...',
        duration: 60,
        order: 2,
        isFree: true,
        videoUrl: 'https://res.cloudinary.com/dccnewrlr/video/upload/v1764252935/VID_20251127_170149_953_i12ngz.mp4',
        resources: [
          { id: '1', name: 'Таблица основных функций', type: 'pdf', size: '1.8 MB' },
          { id: '2', name: 'Примеры функций', type: 'doc', size: '2.3 MB' }
        ]
      },
      {
        courseId: courses[0].id,
        title: 'Пределы функций',
        description: 'Понятие предела функции, основные теоремы о пределах. Вычисление пределов различных типов функций.',
        content: 'Предел функции - это основное понятие математического анализа...',
        duration: 60,
        order: 3,
        isFree: false,
        videoUrl: 'https://res.cloudinary.com/dccnewrlr/video/upload/v1764252935/VID_20251127_170149_953_i12ngz.mp4',
        resources: [
          { id: '1', name: 'Методы вычисления пределов', type: 'pdf', size: '3.2 MB' }
        ]
      },
      {
        courseId: courses[0].id,
        title: 'Производная функции',
        description: 'Определение производной, геометрический и физический смысл. Правила дифференцирования.',
        content: 'Производная функции показывает скорость изменения функции...',
        duration: 60,
        order: 4,
        isFree: false,
        videoUrl: 'https://res.cloudinary.com/dccnewrlr/video/upload/v1764252935/VID_20251127_170149_953_i12ngz.mp4',
        resources: [
          { id: '1', name: 'Таблица производных', type: 'pdf', size: '1.5 MB' },
          { id: '2', name: 'Задачи на производные', type: 'doc', size: '2.8 MB' }
        ]
      }
    ]);
    console.log(`✅ Создано ${lessons.length} уроков`);

    console.log('📝 Создание квизов...');
    const quizzes = await Quiz.bulkCreate([
      {
        courseId: courses[0].id,
        lessonId: lessons[0].id,
        title: 'Квиз по множествам чисел',
        description: 'Проверка знаний по теме "Множества чисел"',
        timeLimit: 15,
        passingScore: 70,
        maxAttempts: 3,
        questionsCount: 4,
        isPublished: true
      },
      {
        courseId: courses[0].id,
        lessonId: lessons[1].id,
        title: 'Квиз по функциям',
        description: 'Проверка знаний по теме "Функции одной переменной"',
        timeLimit: 20,
        passingScore: 70,
        maxAttempts: 3,
        questionsCount: 4,
        isPublished: true
      },
      {
        courseId: courses[0].id,
        lessonId: lessons[2].id,
        title: 'Квиз по пределам',
        description: 'Проверка знаний по теме "Пределы функций"',
        timeLimit: 25,
        passingScore: 70,
        maxAttempts: 3,
        questionsCount: 4,
        isPublished: true
      },
      {
        courseId: courses[0].id,
        lessonId: lessons[3].id,
        title: 'Квиз по производным',
        description: 'Проверка знаний по теме "Производная функции"',
        timeLimit: 30,
        passingScore: 70,
        maxAttempts: 3,
        questionsCount: 4,
        isPublished: true
      }
    ]);
    console.log(`✅ Создано ${quizzes.length} квизов`);

    console.log('❓ Создание вопросов для квиза по множествам чисел...');
    await Question.bulkCreate([
      {
        quizId: quizzes[0].id,
        question: 'Какое из следующих множеств является подмножеством множества действительных чисел?',
        type: 'single',
        options: [
          'Множество натуральных чисел',
          'Множество комплексных чисел',
          'Множество матриц',
          'Множество векторов'
        ],
        correctAnswers: [0],
        points: 1,
        explanation: 'Натуральные числа являются подмножеством действительных чисел, в то время как комплексные числа, матрицы и векторы - нет.',
        order: 1
      },
      {
        quizId: quizzes[0].id,
        question: 'Какое множество обозначается символом ℚ?',
        type: 'single',
        options: [
          'Натуральные числа',
          'Целые числа',
          'Рациональные числа',
          'Действительные числа'
        ],
        correctAnswers: [2],
        points: 1,
        explanation: 'Символ ℚ обозначает множество рациональных чисел.',
        order: 2
      },
      {
        quizId: quizzes[0].id,
        question: 'Какое из чисел является иррациональным?',
        type: 'single',
        options: [
          '0.5',
          '3/4',
          '√2',
          '-2'
        ],
        correctAnswers: [2],
        points: 1,
        explanation: '√2 нельзя представить в виде дроби, поэтому оно является иррациональным числом.',
        order: 3
      },
      {
        quizId: quizzes[0].id,
        question: 'Какое свойство характеризует множество действительных чисел?',
        type: 'single',
        options: [
          'Дискретность',
          'Непрерывность',
          'Конечность',
          'Счетность'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Множество действительных чисел характеризуется свойством непрерывности.',
        order: 4
      }
    ]);

    console.log('❓ Создание вопросов для квиза по функциям...');
    await Question.bulkCreate([
      {
        quizId: quizzes[1].id,
        question: 'Что такое область определения функции?',
        type: 'single',
        options: [
          'Множество значений функции',
          'Множество аргументов функции',
          'Множество производных функции',
          'Множество интегралов функции'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Область определения - это множество всех допустимых значений аргумента функции.',
        order: 1
      },
      {
        quizId: quizzes[1].id,
        question: 'Какая из следующих функций является линейной?',
        type: 'single',
        options: [
          'f(x) = x²',
          'f(x) = 2x + 3',
          'f(x) = sin(x)',
          'f(x) = 1/x'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Функция f(x) = 2x + 3 имеет вид линейной функции y = kx + b.',
        order: 2
      },
      {
        quizId: quizzes[1].id,
        question: 'Что такое множество значений функции?',
        type: 'single',
        options: [
          'Множество всех x, для которых определена функция',
          'Множество всех y, которые принимает функция',
          'Множество производных функции',
          'Множество точек разрыва функции'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Множество значений функции - это все возможные значения, которые принимает функция.',
        order: 3
      },
      {
        quizId: quizzes[1].id,
        question: 'Какая функция называется четной?',
        type: 'single',
        options: [
          'f(-x) = -f(x)',
          'f(-x) = f(x)',
          'f(x) = f(x+1)',
          'f(x) = -f(x)'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Функция называется четной, если f(-x) = f(x) для всех x из области определения.',
        order: 4
      }
    ]);

    console.log('❓ Создание вопросов для квиза по пределам...');
    await Question.bulkCreate([
      {
        quizId: quizzes[2].id,
        question: 'Что означает запись lim(x→a) f(x) = L?',
        type: 'single',
        options: [
          'Функция равна L в точке a',
          'Функция стремится к L при x, стремящемся к a',
          'Производная функции в точке a равна L',
          'Интеграл функции равен L'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Эта запись означает, что функция f(x) приближается к значению L, когда x приближается к a.',
        order: 1
      },
      {
        quizId: quizzes[2].id,
        question: 'Чему равен предел lim(x→0) sin(x)/x?',
        type: 'single',
        options: [
          '0',
          '1',
          '∞',
          'Не существует'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Это первый замечательный предел, который равен 1.',
        order: 2
      },
      {
        quizId: quizzes[2].id,
        question: 'Что такое неопределенность вида 0/0?',
        type: 'single',
        options: [
          'Предел равен 0',
          'Предел равен 1',
          'Нужно применять дополнительные методы',
          'Предел не существует'
        ],
        correctAnswers: [2],
        points: 1,
        explanation: 'Неопределенность 0/0 требует применения специальных методов, таких как правило Лопиталя.',
        order: 3
      },
      {
        quizId: quizzes[2].id,
        question: 'Какое из следующих утверждений о пределах верно?',
        type: 'single',
        options: [
          'Предел суммы равен сумме пределов',
          'Предел произведения всегда равен 0',
          'Предел частного всегда равен 1',
          'Предел не зависит от поведения функции'
        ],
        correctAnswers: [0],
        points: 1,
        explanation: 'Одно из основных свойств пределов: предел суммы равен сумме пределов.',
        order: 4
      }
    ]);

    console.log('❓ Создание вопросов для квиза по производным...');
    await Question.bulkCreate([
      {
        quizId: quizzes[3].id,
        question: 'Что такое производная функции?',
        type: 'single',
        options: [
          'Площадь под кривой',
          'Скорость изменения функции',
          'Максимальное значение функции',
          'Корень функции'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Производная показывает скорость изменения функции в данной точке.',
        order: 1
      },
      {
        quizId: quizzes[3].id,
        question: 'Чему равна производная функции f(x) = x³?',
        type: 'single',
        options: [
          '3x²',
          'x²',
          '3x',
          'x⁴/4'
        ],
        correctAnswers: [0],
        points: 1,
        explanation: "По правилу дифференцирования степенной функции: (xⁿ)' = n*xⁿ⁻¹.",
        order: 2
      },
      {
        quizId: quizzes[3].id,
        question: 'Что показывает вторая производная функции?',
        type: 'single',
        options: [
          'Скорость изменения функции',
          'Ускорение изменения функции',
          'Максимум функции',
          'Область определения'
        ],
        correctAnswers: [1],
        points: 1,
        explanation: 'Вторая производная показывает скорость изменения первой производной, то есть ускорение.',
        order: 3
      },
      {
        quizId: quizzes[3].id,
        question: 'Какое правило используется для дифференцирования произведения функций?',
        type: 'single',
        options: [
          'Правило суммы',
          'Правило Лопиталя',
          'Правило произведения',
          'Правило цепи'
        ],
        correctAnswers: [2],
        points: 1,
        explanation: "Для произведения функций используется правило: (uv)' = u\'v + uv\'.",
        order: 4
      }
    ]);

    console.log('✅ Создано 16 вопросов для 4 квизов');

    // Создание достижений
    console.log('🏆 Создание достижений...');
    const achievements = await Achievement.bulkCreate([
      {
        courseId: courses[0].id,
        name: 'Первый шаг в анализе',
        description: 'Завершите первый урок курса по математическому анализу',
        icon: 'first-step.png',
        type: 'lesson_completion',
        criteria: { firstLesson: true, lessonsCompleted: 1 },
        rarity: 'common',
        xpReward: 100
      },
      {
        courseId: courses[0].id,
        name: 'Знаток функций',
        description: 'Завершите 3 урока курса',
        icon: 'function-master.png',
        type: 'lesson_completion',
        criteria: { lessonsCompleted: 3 },
        rarity: 'rare',
        xpReward: 200
      },
      {
        courseId: courses[0].id,
        name: 'Мастер математического анализа',
        description: 'Завершите весь курс математического анализа',
        icon: 'math-master.png',
        type: 'course_completion',
        criteria: { targetCount: 1 },
        rarity: 'epic',
        xpReward: 500
      },
      {
        courseId: courses[0].id,
        name: 'Идеальный результат',
        description: 'Получите 100% баллов в любом квизе',
        icon: 'perfect-score.png',
        type: 'perfect_score',
        criteria: { minScore: 100, targetCount: 1 },
        rarity: 'rare',
        xpReward: 150
      }
    ]);
    console.log(`✅ Создано ${achievements.length} достижений`);

    console.log('🎉 Сидирование базы данных завершено успешно!');
    console.log('\n📊 Статистика созданных данных:');
    console.log(`   📚 Курсы: ${courses.length}`);
    console.log(`   📖 Уроки: ${lessons.length}`);
    console.log(`   📝 Квизы: ${quizzes.length}`);
    console.log(`   ❓ Вопросы: 16`);
    console.log(`   🏆 Достижения: ${achievements.length}`);

  } catch (error) {
    console.error('❌ Ошибка при сидировании базы данных:', error);
    process.exit(1);
  } finally {
    await sequelize.close();
    console.log('🔌 Подключение к базе данных закрыто');
  }
};

seedDatabase();